"""
БЫСТРОЕ ИСПРАВЛЕНИЕ БД - Запустите ОДИН раз!
Для Pydroid3 и других окружений
"""
import os
import sqlite3

# Путь к БД
DB_PATH = "database/t_league.db"

print("=" * 50)
print("🔧 T-League Bot - Исправление базы данных")
print("=" * 50)

# Проверка существования БД
if not os.path.exists(DB_PATH):
    print("❌ База данных не найдена!")
    print("✅ При первом запуске бота она создастся автоматически")
    print("   Просто запустите: python bot.py")
    exit()

print(f"\n📂 Найдена БД: {DB_PATH}")
print("🔍 Проверяем структуру...")

# Подключение
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# Проверка tournaments
cursor.execute("PRAGMA table_info(tournaments)")
tournaments_cols = {col[1] for col in cursor.fetchall()}

# Проверка matches
cursor.execute("PRAGMA table_info(matches)")
matches_cols = {col[1] for col in cursor.fetchall()}

print(f"   Поля tournaments: {len(tournaments_cols)}")
print(f"   Поля matches: {len(matches_cols)}")

# Нужные поля
needed_tournament_fields = {
    'registration_open': 'BOOLEAN DEFAULT 0',
    'draw_completed': 'BOOLEAN DEFAULT 0',
    'total_rounds': 'INTEGER DEFAULT 0'
}

needed_match_fields = {
    'deadline_set': 'BOOLEAN DEFAULT 0'
}

# Добавление недостающих полей
added = 0

print("\n🔧 Добавление недостающих полей...")

for field, type_def in needed_tournament_fields.items():
    if field not in tournaments_cols:
        try:
            cursor.execute(f"ALTER TABLE tournaments ADD COLUMN {field} {type_def}")
            print(f"   ✅ Добавлено: tournaments.{field}")
            added += 1
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")

for field, type_def in needed_match_fields.items():
    if field not in matches_cols:
        try:
            cursor.execute(f"ALTER TABLE matches ADD COLUMN {field} {type_def}")
            print(f"   ✅ Добавлено: matches.{field}")
            added += 1
        except Exception as e:
            print(f"   ❌ Ошибка: {e}")

if added > 0:
    conn.commit()
    print(f"\n✅ Успешно добавлено полей: {added}")
    print("🚀 Теперь запустите: python bot.py")
else:
    print("\n✅ База данных уже обновлена!")
    print("🚀 Можете запускать бота: python bot.py")

conn.close()

print("\n" + "=" * 50)
print("✅ Готово!")
print("=" * 50)
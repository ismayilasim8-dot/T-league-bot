"""
Скрипт миграции базы данных T-League Bot v1.0.0 → v1.1.0
Запустите ОДИН РАЗ перед запуском бота!
"""
import sqlite3
import os

DB_PATH = "database/t_league.db"

def migrate_database():
    """Обновление структуры базы данных"""
    
    if not os.path.exists(DB_PATH):
        print("❌ База данных не найдена. Создайте её запустив бота.")
        return
    
    print("🔄 Начинаем миграцию базы данных...")
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # Проверяем, есть ли уже новые поля
        cursor.execute("PRAGMA table_info(tournaments)")
        columns = [col[1] for col in cursor.fetchall()]
        
        # Добавляем новые поля в таблицу tournaments
        if 'registration_open' not in columns:
            print("  ➕ Добавление поля registration_open...")
            cursor.execute("ALTER TABLE tournaments ADD COLUMN registration_open BOOLEAN DEFAULT 0")
        
        if 'draw_completed' not in columns:
            print("  ➕ Добавление поля draw_completed...")
            cursor.execute("ALTER TABLE tournaments ADD COLUMN draw_completed BOOLEAN DEFAULT 0")
        
        if 'total_rounds' not in columns:
            print("  ➕ Добавление поля total_rounds...")
            cursor.execute("ALTER TABLE tournaments ADD COLUMN total_rounds INTEGER DEFAULT 0")
        
        # Проверяем таблицу matches
        cursor.execute("PRAGMA table_info(matches)")
        match_columns = [col[1] for col in cursor.fetchall()]
        
        if 'deadline_set' not in match_columns:
            print("  ➕ Добавление поля deadline_set...")
            cursor.execute("ALTER TABLE matches ADD COLUMN deadline_set BOOLEAN DEFAULT 0")
        
        conn.commit()
        print("✅ Миграция завершена успешно!")
        print("🚀 Теперь можете запустить бота: python bot.py")
        
    except Exception as e:
        print(f"❌ Ошибка миграции: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_database()